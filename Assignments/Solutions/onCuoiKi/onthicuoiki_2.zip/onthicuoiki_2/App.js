
import Screen1 from './pages/screen1';
import Screen2 from './pages/screen2';
import Screen3 from './pages/screen3';
import FormBike from './pages/formBike';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import store from './redux_toolkit/store/store';
import { Provider } from 'react-redux';


const Stack = createStackNavigator();

export default function App() {
  return (
    <Provider store={store}>
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Screen1">
         <Stack.Screen name="Screen1" component={Screen1} options={{ headerShown: false }}/>
         <Stack.Screen name="Screen2" component={Screen2}/>
         <Stack.Screen name="formBike" component={FormBike}/>
         <Stack.Screen name="Screen3" component={Screen3}/>
          
      </Stack.Navigator>
    </NavigationContainer>
    </Provider>
  );
}