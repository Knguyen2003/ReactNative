import React, {useState} from 'react';
import Swiper from 'react-native-swiper';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Image,
  Dimensions
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';

const { width } = Dimensions.get('window');
    


const Screen1 = ({ navigation }) => {

  return (
    <SafeAreaView style={screen1.container}>
      <View style={screen1.top}>
          <View style={{backgroundColor :'red', width:120, height:120, position:'relative'}}>
              <AntDesign
                  name= "heart"
                  size = {30}
                  color= 'blue'
                  style = {screen1.heart}
              />
          </View>

      </View>
      <View style={screen1.center}>
        <Swiper
          autoplay
          autoplayTimeout={2} // Tự động cuộn sau 3 giây
          loop
          dotStyle={screen1.dot} // Style cho dot không active
          activeDotStyle={screen1.activeDot} // Style cho dot active
        >
          {/* Thay vì dùng mảng, thêm trực tiếp các ảnh */}
          <Image
            source={require('../assets/2.jpg')}
            style={screen1.bannerImage}
          />
          <Image
            source={require('../assets/3.jpg')}
            style={screen1.bannerImage}
          />
          <Image
            source={require('../assets/1.jpg')}
            style={screen1.bannerImage}
          />
        </Swiper>
      </View>
      <View style={screen1.footer}>
        <Text style={{ fontSize: 25, fontWeight: 'bold', textAlign: 'center' }}>
          POWER BIKE {'\n'} SHOP
        </Text>
        <TouchableOpacity style={screen1.buttonView}>
          <Text
            style={{
              color: 'white',
              fontWeight: 'bold',
              fontSize: 20,
              textAlign: 'center',
            }}
            onPress={() => navigation.navigate('Screen2')}>
            Get Started
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const screen1 = StyleSheet.create({
  container: {
    flex: 1,
  },
  top: {
    flex: 2,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  center: {
    flex: 2,
    padding: 10,
  },
  footer: {
    flex: 1,
    padding: 10,
    justifyContent: 'space-between',
  },
  buttonView: {
    backgroundColor: '#e94141',
    padding: 20,
    borderRadius: 40,
    marginBottom: 20,
  },
  bannerImage: {
    width,
    height: 200, // Chiều cao của banner (có thể thay đổi theo nhu cầu)
    resizeMode: 'cover',
  },
  dot: {
    backgroundColor: 'rgba(0,0,0,0.2)',
    width: 8,
    height: 8,
    borderRadius: 4,
    margin: 3,
  },
  activeDot: {
    backgroundColor: '#007AFF',
    width: 8,
    height: 8,
    borderRadius: 4,
    margin: 3,
  },
  heart :{
    position:'absolute',
    top : 25,
  },
});

export default Screen1;
