import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';

import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts } from '../redux_toolkit/slice/bikeSliceAPI';

const categoryArray = ['ALL', 'Roadbike', 'Mountain'];

const Screen2 = ({ navigation }) => {
  const { products, loading, error } = useSelector((state) => state.productAPI);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  const chuyenAnh = (anh) => {
    switch (anh) {
      case 'image1':
        return (
          <Image
            source={require('../assets/bione-removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      case 'image2':
        return (
          <Image
            source={require('../assets/bitwo-removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      case 'image3':
        return (
          <Image
            source={require('../assets/bithree_removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      case 'image4':
        return (
          <Image
            source={require('../assets/bifour_-removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      default:
        return (
          <Image
            source={{ uri: anh.uri }}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
    }
  };

  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [filteredData, setFilteredData] = useState(products);

  const handleCategoryPress = (category) => {
    setSelectedCategory(category);
    if (category === 'ALL') {
      setFilteredData(products); // Hiển thị tất cả dữ liệu
    } else {
      setFilteredData(products.filter((item) => item.type === category)); // Lọc theo danh mục
    }
  };

  useEffect(() => {
    if (selectedCategory === 'ALL') {
      setFilteredData(products);
    } else {
      setFilteredData(
        products.filter((item) => item.type === selectedCategory)
      );
    }
  }, [products, selectedCategory]);

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  if (error) {
    return <Text>Error: {error}</Text>;
  }

  const showCategory = ({ item }) => {
    return (
      <TouchableOpacity
        style={styles.categoryItem}
        onPress={() => handleCategoryPress(item)}>
        <Text
          style={[
            { fontSize: 15, fontWeight: 'bold' },
            selectedCategory == item && { color: 'red' },
          ]}>
          {item}
        </Text>
      </TouchableOpacity>
    );
  };

  const showProduct = ({ item }) => {
    return (
      <TouchableOpacity
        style={styles.productItem}
        onPress={() => navigation.navigate('Screen3', { bike: item })}>
        {chuyenAnh(item.image)}
        <Text style={{ fontSize: 15, fontWeight: 'bold' }}>{item.name}</Text>
        <Text style={{ fontSize: 15, fontWeight: 'bold' }}>$ {item.price}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={{ color: '#f28e8e', fontWeight: 'bold', fontSize: 25 }}>
          The world's Best Bike
        </Text>
        <TouchableOpacity
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'red',
            padding: 5,
            marginRight: 10,
          }}
          onPress={() => navigation.navigate('formBike')}>
          <Text>ADD </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.categoryView}>
        <FlatList
          data={categoryArray}
          keyExtractor={(item, index) => item.toString()}
          renderItem={showCategory}
          horizontal={true}
          contentContainerStyle={styles.flatListContainer}
        />
      </View>

      <View style={styles.content}>
        <FlatList
          data={filteredData}
          keyExtractor={(item) => item.id}
          renderItem={showProduct}
          numColumns={2}
          columnWrapperStyle={styles.rowProduct}
          showsVerticalScrollIndicator={true}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#ffffff',
  },
  header: {
    flex: 0.5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  categoryView: {
    flex: 0.5,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  categoryItem: {
    borderWidth: 2,
    borderColor: '#ec5b5b',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    width: 100,
    borderRadius: 5,
  },
  flatListContainer: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  productItem: {
    width: 170,
    padding: 5,
    alignItems: 'center',
    backgroundColor: '#fef5ed',
    borderRadius: 10,
  },
  rowProduct: {
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom: 10,
  },
  content: {
    flex: 4,
    paddingTop: 15,
  },
});

export default Screen2;
