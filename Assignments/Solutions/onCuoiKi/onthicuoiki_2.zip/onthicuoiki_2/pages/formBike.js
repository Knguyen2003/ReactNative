import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Image,
  Alert,
  TouchableOpacity,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';

import * as ImagePicker from 'expo-image-picker';

import { useSelector, useDispatch } from 'react-redux';
import { addProduct, updateProduct } from '../redux_toolkit/slice/bikeSliceAPI';

import * as ImageManipulator from 'expo-image-manipulator';

const AddProductScreen = ({ navigation, route }) => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [type, setCategory] = useState('Roadbike');
  const [image, setImageUri] = useState(null);

  const dispatch = useDispatch();

  const chuyenAnh = (anh) => {
    switch (anh) {
      case 'image1':
        return require('../assets/bione-removebg-preview.png');
      case 'image2':
        return require('../assets/bitwo-removebg-preview.png');
      case 'image3':
        return require('../assets/bithree_removebg-preview.png');
      case 'image4':
        return require('../assets/bifour_-removebg-preview.png');
      default:
        return {uri : anh.uri};
    }
  };


  //Cập nhật
  const isEditMode = !!route.params?.bike; // Kiểm tra xem có truyền thông tin sản phẩm hay không
  const bikeToEdit = route.params?.bike;

  useEffect(() => {
    if (isEditMode) {
      setName(bikeToEdit.name);
      setPrice(bikeToEdit.price.toString());
      setCategory(bikeToEdit.type);
      if (bikeToEdit.image?.uri) {
        setImageUri(bikeToEdit.image.uri);
      } else {
        setImageUri(chuyenAnh(bikeToEdit.image));
      }
    }
  }, [isEditMode, bikeToEdit]);

  // Hàm để chọn ảnh từ thư viện ảnh
  const pickImage = async () => {
    // Xin quyền truy cập ảnh
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permissionResult.granted === false) {
      Alert.alert(
        'Lỗi',
        'Bạn cần cấp quyền truy cập thư viện ảnh để chọn ảnh.'
      );
      return;
    }

    // Mở thư viện ảnh
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled) {
      setImageUri(result.assets[0].uri); // Lưu đường dẫn ảnh đã chọn
    }
  };

  const compressImage = async (uri) => {
    const manipResult = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: 500 } }], // Giảm kích thước ảnh xuống 500px (hoặc tuỳ chỉnh)
      { format: 'jpeg', compress: 0.7 } // Giảm chất lượng ảnh nếu cần
    );
    return manipResult.uri;
  };

  const handleAddProduct = async () => {
    if (!name || !price || !image) {
      Alert.alert(
        'Lỗi',
        'Vui lòng điền đầy đủ thông tin và chọn ảnh cho sản phẩm'
      );
      return;
    }

    const compressedImageUri = await compressImage(image);

    const newProduct = {
      name,
      price,
      type,
      image: { uri: compressedImageUri },
    };

    dispatch(addProduct(newProduct))
      .unwrap()
      .then(() => {
        Alert.alert('Thêm sản phẩm thành công');
        navigation.goBack();
      })
      .catch((error) => {
        console.error('Thêm thất bại', error);
        Alert.alert('Thêm thất bại');
      });
  };

  

  const handleUpdateProduct = async () =>{
    console.log(image);
    console.log(chuyenAnh(bikeToEdit.image));


    const updatedProductData = {
      id: bikeToEdit.id, // ID của sản phẩm đang cần cập nhật
      updatedProduct: {
        name,
        price: parseFloat(price),
        type,
        image:  image === chuyenAnh(bikeToEdit.image) ? bikeToEdit.image  : { uri: await compressImage(image) },
      },
    };

    console.log(updatedProductData);

    dispatch(updateProduct(updatedProductData))
    .unwrap()
    .then(() => {
      Alert.alert('Cập nhật thành công');
      navigation.goBack();
    })
    .catch((error) => {
      Alert.alert('Cập nhật thất bại');
      console.error('Lỗi cập nhật: ', error);
    });
    Alert.alert('Cập nhật thành công', 'Sản phẩm đã được cập nhật');
    navigation.navigate('Screen2');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Tên xe:</Text>
      <TextInput
        style={styles.input}
        value={name}
        onChangeText={setName}
        placeholder="Nhập tên xe"
      />

      <Text style={styles.label}>Giá xe:</Text>
      <TextInput
        style={styles.input}
        value={price}
        onChangeText={setPrice}
        placeholder="Nhập giá xe"
        keyboardType="numeric"
      />

      <Text style={styles.label}>Loại xe:</Text>
      <Picker
        selectedValue={type}
        style={styles.picker}
        onValueChange={(itemValue) => setCategory(itemValue)}>
        <Picker.Item label="Roadbike" value="Roadbike" />
        <Picker.Item label="Mountain" value="Mountain" />
      </Picker>

      <Text style={styles.label}>Ảnh sản phẩm:</Text>

      {image ? (
        typeof image === 'string' ? (
          // Nếu `image` là URL
          <Image source={{ uri: image }} style={styles.image} />
        ) : (
          // Nếu `image` là local asset thông qua require
          <Image source={image} style={styles.image} />
        )
      ) : (
        // Nếu không có ảnh thì hiển thị placeholder
        <View style={styles.imagePlaceholder}>
          <Text style={styles.imageText}>TRỐNG</Text>
        </View>
      )}
      <TouchableOpacity style={styles.button} onPress={pickImage}>
        <Text style={styles.buttonText}>Chọn ảnh</Text>
      </TouchableOpacity>

      {isEditMode ? (
        <TouchableOpacity onPress={()=>handleUpdateProduct()}>
          <Text>UPDATE PRODUCT</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={handleAddProduct}>
          <Text>ADD PRODUCT</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 15,
    paddingHorizontal: 10,
  },
  picker: {
    height: 50,
    width: '100%',
    marginBottom: 15,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginBottom: 15,
  },
  imagePlaceholder: {
    width: 100,
    height: 100,
    backgroundColor: '#ccc',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    marginBottom: 15,
  },
  imageText: {
    color: '#666',
  },
});

export default AddProductScreen;
