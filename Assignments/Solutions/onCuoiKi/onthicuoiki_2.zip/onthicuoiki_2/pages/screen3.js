import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
} from 'react-native';

import { useSelector, useDispatch } from 'react-redux';
import { deleteProduct } from '../redux_toolkit/slice/bikeSliceAPI';

const Screen3 = ({ navigation, route }) => {
  const { bike } = route.params;

  const dispatch = useDispatch();

  const handleDeleteProduct = (id) => {
    dispatch(deleteProduct(id)); // Thực hiện xóa sản phẩm
    navigation.navigate('Screen2'); // Di chuyển về Screen2 sau khi xóa thành công
  };

  const handleUpdateProduct = () => {
    navigation.navigate('formBike', { bike: bike });
  };

   const chuyenAnh = (anh) => {
    switch (anh) {
      case 'image1':
        return (
          <Image
            source={require('../assets/bione-removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      case 'image2':
        return (
          <Image
            source={require('../assets/bitwo-removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      case 'image3':
        return (
          <Image
            source={require('../assets/bithree_removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      case 'image4':
        return (
          <Image
            source={require('../assets/bifour_-removebg-preview.png')}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
      default:
        return (
          <Image
            source={{uri : anh.uri}}
            style={{ width: 150, height: 150, resizeMode: 'contain' }}
          />
        );
    }
  };

  return (
    <SafeAreaView style={screen3.container}>
      <View style={screen3.top}>
        {chuyenAnh(bike.image)}
      </View>
      <View style={screen3.center}>
        <View style={{ flexDirection: 'row' }}>
          <Text style={{ color: '#6E6E6E', marginRight: 30, fontSize: 15 }}>
            15% OFF I 350$
          </Text>
          <Text
            style={{
              fontWeight: 'bold',
              fontSize: 15,
              textDecorationLine: 'line-through',
            }}>
            449$
          </Text>
        </View>
        <Text style={{ fontWeight: 'bold', fontSize: 15, marginVertical: 20 }}>
          Description
        </Text>
        <Text style={{ color: '#6E6E6E' }}>
          It is a very important form of writing as we write almost everything
          in paragraphs, be it an answer, essay, story, emails, etc.
        </Text>
      </View>
      <View style={screen3.footer}>
        <TouchableOpacity
          style={screen3.button}
          onPress={() => handleUpdateProduct()}>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'white',
              fontSize: 20,
              textAlign: 'center',
            }}>
            Update
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={screen3.button}>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'white',
              fontSize: 20,
              textAlign: 'center',
            }}
            onPress={() => handleDeleteProduct(bike.id)}>
            Delete
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const screen3 = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#ffffff',
  },
  top: {
    flex: 2,
    backgroundColor: '#fdeded',
    margin: 10,
  },
  center: {
    flex: 1,
    padding: 10,
  },
  footer: {
    flex: 0,
    flexDirection: 'row',
    padding: 10,
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    backgroundColor: '#e94141',
  },
});

export default Screen3;
