import { configureStore } from '@reduxjs/toolkit';
import bikeReducer from '../slice/bikeSliceArray';
import bikeAPIReducer from '../slice/bikeSliceAPI';

const store = configureStore({
  reducer: {
    products: bikeReducer,
    productAPI: bikeAPIReducer,
  },
});

export default store;