import { configureStore } from '@reduxjs/toolkit';
import bikeReducer from '../slice/bikeSliceArray';

const store = configureStore({
  reducer: {
    products: bikeReducer,
  },
});

export default store;