import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  products:   [
    {
      id : 1,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 1800,
      name : "Pinarello",
      heart : false,
      type : "Roadbike"
    },

     {
      id : 2,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 2700,
      name : "Pinarello",
      heart : false,
       type : "Roadbike"
    },

     {
      id : 3,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 1500,
      name : "Pina Bike",
      heart : false,
       type : "Roadbike"
    },

     {
      id : 4,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 1700,
      name : "Pina Mountai",
      heart : false,
      type : "Roadbike"
    },

    {
      id : 5,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 1800,
      name : "Pinarello",
      heart : false,
      type : "Mountain"
    },

     {
      id : 6,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 1800,
      name : "Pinarello",
      heart : false,
      type : "Mountain"
    },

     {
      id : 7,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 1800,
      name : "Pina Bike",
      heart : false,
      type : "Mountain"
    },

     {
      id : 8,
      image :require('../../assets/bifour_-removebg-preview.png'),
      price : 1800,
      name : "Pina Mountai",
      heart : false,
      type : "Mountain"
    },
  ],
};

const productSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    addProduct: (state, action) => { // Thêm sản phẩm
      state.products.push(action.payload);
    },
    deleteProduct: (state, action) => {// Xóa sản phẩm
      state.products = state.products.filter(
        (product) => product.id !== action.payload 
      );
    },
    updateProduct: (state, action) => {// Sửa sản phẩm
      const { id, updatedProduct } = action.payload; 
      const index = state.products.findIndex((product) => product.id === id);
      if (index !== -1) {
        state.products[index] = { ...state.products[index], ...updatedProduct };
      }
    },
  },
});

export const {addProduct, deleteProduct, updateProduct } = productSlice.actions;
export default productSlice.reducer;
